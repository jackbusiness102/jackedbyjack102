/* ============================================================
   JackedByJack Coach Dashboard — App Logic
   Data persists via localStorage
   ============================================================ */

// ── Default data ────────────────────────────────────────────
const DEFAULT_CLIENTS = [
  { id:1,  fn:'Darren',  ln:'',        goal:'Strength',       freq:3, sw:95,  tw:85,  email:'darren@email.com',  phone:'+27 82 111 0001', active:true,  avatar:'DA', color:'green' },
  { id:2,  fn:'Lizelle', ln:'',        goal:'Fat loss',        freq:2, sw:78,  tw:65,  email:'lizelle@email.com', phone:'+27 82 111 0002', active:true,  avatar:'LI', color:'blue'  },
  { id:3,  fn:'Clarissa',ln:'',        goal:'Muscle gain',     freq:3, sw:62,  tw:68,  email:'clarissa@email.com',phone:'+27 82 111 0003', active:true,  avatar:'CL', color:'orange'},
  { id:4,  fn:'Anton',   ln:'',        goal:'Strength',        freq:2, sw:102, tw:92,  email:'anton@email.com',   phone:'+27 82 111 0004', active:true,  avatar:'AN', color:'green' },
  { id:5,  fn:'Pip',     ln:'',        goal:'General fitness', freq:2, sw:70,  tw:66,  email:'pip@email.com',     phone:'+27 82 111 0005', active:true,  avatar:'PI', color:'blue'  },
  { id:6,  fn:'Jacques', ln:'',        goal:'Fat loss',        freq:3, sw:110, tw:90,  email:'jacques@email.com', phone:'+27 82 111 0006', active:false, avatar:'JA', color:'orange'},
  { id:7,  fn:'Joshua',  ln:'',        goal:'Muscle gain',     freq:4, sw:74,  tw:80,  email:'joshua@email.com',  phone:'+27 82 111 0007', active:true,  avatar:'JO', color:'green' },
  { id:8,  fn:'Jono',    ln:'',        goal:'Fat loss',        freq:2, sw:88,  tw:78,  email:'jono@email.com',    phone:'+27 82 111 0008', active:true,  avatar:'JN', color:'blue'  },
  { id:9,  fn:'Mikayla', ln:'',        goal:'Fat loss',        freq:3, sw:72,  tw:62,  email:'mikayla@email.com', phone:'+27 82 111 0009', active:true,  avatar:'MI', color:'orange'},
];

const DEFAULT_WEIGHTS = {
  1:[95,93,92,91,90,89.5,89],
  2:[78,76.5,75,74,73,72.5,72.5],
  3:[62,62.5,63,63.5,64,64,64],
  4:[102,101,100,99,98.5,98,98],
  5:[70,69.8,69.5,69.2,69,69,69],
  6:[110,108,106,105,104,103.5,103],
  7:[74,74.5,75,76,76.5,77,77],
  8:[88,87,86,85.5,85,84.5,84],
  9:[72,71.2,70.4,69.8,69,68.7,68.4],
};

const DEFAULT_SESSIONS = [
  { id:1, clientId:1, date:'25 Mar', type:'Strength – lower body',   notes:'Good energy, hit 100kg squat.', exercises:[{name:'Squat',sets:4,reps:6,weight:100},{name:'RDL',sets:3,reps:8,weight:70},{name:'Leg press',sets:3,reps:12,weight:120}] },
  { id:2, clientId:2, date:'24 Mar', type:'Fat loss circuit',         notes:'',                              exercises:[{name:'KB swings',sets:4,reps:15,weight:20},{name:'Burpees',sets:3,reps:10,weight:0},{name:'Row',sets:3,reps:12,weight:40}] },
  { id:3, clientId:5, date:'27 Mar', type:'Strength – upper body',    notes:'Upper body hypertrophy session.',exercises:[{name:'Bench press',sets:4,reps:8,weight:60},{name:'Barbell row',sets:4,reps:8,weight:55},{name:'Shoulder press',sets:3,reps:10,weight:35}] },
  { id:4, clientId:3, date:'26 Mar', type:'Strength – lower body',    notes:'New PR – 80kg squat!',          exercises:[{name:'Squat',sets:4,reps:5,weight:80},{name:'Hip thrust',sets:4,reps:10,weight:90},{name:'Lunge',sets:3,reps:12,weight:20}] },
  { id:5, clientId:9, date:'26 Mar', type:'Fat loss circuit',         notes:'',                              exercises:[{name:'Deadlift',sets:3,reps:8,weight:60},{name:'Push-up',sets:3,reps:15,weight:0}] },
];

const DEFAULT_SCHEDULE = [
  { day:'Mon', time:'07:00', clientId:1, type:'1-on-1' },
  { day:'Mon', time:'09:00', clientId:2, type:'1-on-1' },
  { day:'Mon', time:'11:00', clientId:4, type:'1-on-1' },
  { day:'Tue', time:'07:00', clientId:5, type:'1-on-1' },
  { day:'Tue', time:'09:00', clientId:3, type:'1-on-1' },
  { day:'Tue', time:'17:30', clientId:0, type:'S&C Class' },
  { day:'Wed', time:'08:00', clientId:7, type:'1-on-1' },
  { day:'Wed', time:'10:00', clientId:8, type:'1-on-1' },
  { day:'Thu', time:'07:00', clientId:9, type:'1-on-1' },
  { day:'Thu', time:'09:00', clientId:6, type:'1-on-1' },
  { day:'Thu', time:'17:30', clientId:0, type:'S&C Class' },
  { day:'Fri', time:'08:00', clientId:2, type:'1-on-1' },
  { day:'Fri', time:'10:00', clientId:1, type:'1-on-1' },
  { day:'Sat', time:'09:00', clientId:8, type:'1-on-1' },
];

const DEFAULT_PRS = {
  1:[{lift:'Squat',weight:'100kg'},{lift:'Deadlift',weight:'120kg'}],
  2:[{lift:'KB swing',weight:'24kg'},{lift:'Row (machine)',weight:'55kg'}],
  3:[{lift:'Squat',weight:'80kg'},{lift:'Hip thrust',weight:'90kg'},{lift:'Deadlift',weight:'80kg'}],
  4:[{lift:'Deadlift',weight:'180kg'},{lift:'Bench press',weight:'110kg'}],
  5:[{lift:'Bench press',weight:'60kg'},{lift:'Squat',weight:'65kg'}],
  6:[{lift:'Squat',weight:'120kg'},{lift:'Deadlift',weight:'140kg'}],
  7:[{lift:'Bench press',weight:'85kg'},{lift:'Pull-up',weight:'BW+10kg'}],
  8:[{lift:'Deadlift',weight:'110kg'},{lift:'Squat',weight:'90kg'}],
  9:[{lift:'Hip thrust',weight:'80kg'},{lift:'Squat',weight:'55kg'}],
};

const EXERCISE_LIST = ['Back squat','Front squat','Deadlift','Romanian deadlift','Hip thrust','Leg press','Lunge','Step-up','Bench press','Incline bench','Shoulder press','Pull-up','Barbell row','Cable row','Lat pulldown','Dumbbell curl','Tricep dip','Plank','KB swing','Burpee','Push-up','Box jump','Sled push','Battle ropes'];

const TIMES = ['06:00','07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','17:30','18:00','19:00'];
const DAYS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

// ── Storage helpers ──────────────────────────────────────────
function load(key, def) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : def; } catch { return def; }
}
function save(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

// ── App state ────────────────────────────────────────────────
let clients  = load('jbj_clients',  DEFAULT_CLIENTS);
let weights  = load('jbj_weights',  DEFAULT_WEIGHTS);
let sessions = load('jbj_sessions', DEFAULT_SESSIONS);
let schedule = load('jbj_schedule', DEFAULT_SCHEDULE);
let prs      = load('jbj_prs',      DEFAULT_PRS);
let exerciseRows = [];
let detailClientId = null;

// ── Nav ──────────────────────────────────────────────────────
function nav(page, el) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  if (el) el.classList.add('active');
  if (page === 'dashboard') renderDashboard();
  if (page === 'clients')   renderClients();
  if (page === 'workouts')  renderWorkouts();
  if (page === 'progress')  { populateProgressSelect(); renderProgress(); }
  if (page === 'schedule')  renderSchedule();
}

// ── DASHBOARD ────────────────────────────────────────────────
function renderDashboard() {
  const now = new Date();
  document.getElementById('dash-date').textContent = now.toLocaleDateString('en-ZA', { weekday:'long', day:'numeric', month:'long', year:'numeric' });

  const activeClients = clients.filter(c => c.active);
  document.getElementById('stat-clients').textContent = activeClients.length;
  document.getElementById('stat-sessions').textContent = schedule.length;
  document.getElementById('stat-logged').textContent = sessions.length;

  // Today's sessions
  const todayDay = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][now.getDay()];
  const todaySch = schedule.filter(s => s.day === todayDay).sort((a,b)=>a.time.localeCompare(b.time));
  document.getElementById('today-count').textContent = todaySch.length + ' today';
  document.getElementById('today-sessions').innerHTML = todaySch.length ? todaySch.map(s => {
    const c = s.clientId === 0 ? null : clients.find(c => c.id === s.clientId);
    const name = s.type === 'S&C Class' ? 'S&C Group Class' : (c ? c.fn : 'Unknown');
    const now2 = now.getHours() * 60 + now.getMinutes();
    const [h,m] = s.time.split(':').map(Number);
    const past = now2 > h*60+m;
    return `<div class="session-row">
      <span class="session-time">${s.time}</span>
      <div class="session-info"><div class="session-name">${name}</div><div class="session-type-label">${s.type}</div></div>
      <span class="badge ${past?'badge-mono':'badge-green'}">${past?'Done':'Upcoming'}</span>
    </div>`;
  }).join('') : '<p style="color:var(--text-muted);font-size:13px;">No sessions today.</p>';

  // Activity feed
  const recent = [...sessions].sort((a,b) => b.id - a.id).slice(0, 6);
  document.getElementById('activity-list').innerHTML = recent.map(s => {
    const c = clients.find(c => c.id === s.clientId);
    return `<div class="activity-item">
      <span class="activity-time">${s.date}</span>
      <span>${c ? c.fn : 'Client'} completed ${s.type.toLowerCase()}</span>
    </div>`;
  }).join('');
}

// ── CLIENTS ──────────────────────────────────────────────────
function renderClients(filter = '') {
  const filtered = clients.filter(c => (c.fn + ' ' + c.ln + ' ' + c.goal).toLowerCase().includes(filter.toLowerCase()));
  document.getElementById('client-grid').innerHTML = filtered.map(c => {
    const cw = (weights[c.id] || [c.sw]);
    const current = cw[cw.length - 1];
    const pct = c.sw === c.tw ? 100 : Math.min(100, Math.max(0, Math.round(Math.abs(c.sw - current) / Math.abs(c.sw - c.tw) * 100)));
    return `<div class="client-card" onclick="openClientDetail(${c.id})">
      <div class="client-avatar" style="${avatarStyle(c.color)}">${c.avatar}</div>
      <div class="client-name">${c.fn}${c.ln ? ' '+c.ln : ''}</div>
      <div class="client-meta">${c.goal} · ${c.freq}×/wk</div>
      <span class="badge ${c.active ? 'badge-green' : 'badge-mono'}">${c.active ? 'Active' : 'Paused'}</span>
      <div class="progress-wrap">
        <div class="progress-label"><span>Progress to goal</span><span>${pct}%</span></div>
        <div class="progress-bar"><div class="progress-fill ${c.color === 'blue' ? 'blue' : ''}" style="width:${pct}%"></div></div>
      </div>
    </div>`;
  }).join('');
}

function avatarStyle(color) {
  const map = { green:'background:var(--accent-dim);color:var(--accent);', blue:'background:var(--blue-dim);color:var(--blue);', orange:'background:var(--orange-dim);color:var(--orange);' };
  return map[color] || map.green;
}

function filterClients() {
  renderClients(document.getElementById('client-search').value);
}

function openClientDetail(id) {
  detailClientId = id;
  const c = clients.find(c => c.id === id);
  const cw = weights[id] || [c.sw];
  const current = cw[cw.length - 1];
  document.getElementById('detail-name').textContent = c.fn + (c.ln ? ' '+c.ln : '');
  document.getElementById('client-detail-body').innerHTML = `
    <div class="detail-grid">
      <div class="detail-field"><div class="detail-field-label">Goal</div><div class="detail-field-value">${c.goal}</div></div>
      <div class="detail-field"><div class="detail-field-label">Sessions / week</div><div class="detail-field-value">${c.freq}×</div></div>
      <div class="detail-field"><div class="detail-field-label">Start weight</div><div class="detail-field-value">${c.sw} kg</div></div>
      <div class="detail-field"><div class="detail-field-label">Current weight</div><div class="detail-field-value">${current} kg</div></div>
      <div class="detail-field"><div class="detail-field-label">Target weight</div><div class="detail-field-value">${c.tw} kg</div></div>
      <div class="detail-field"><div class="detail-field-label">Status</div><div class="detail-field-value">${c.active ? '✓ Active' : '⏸ Paused'}</div></div>
      <div class="detail-field"><div class="detail-field-label">Email</div><div class="detail-field-value" style="font-size:12px;">${c.email || '—'}</div></div>
      <div class="detail-field"><div class="detail-field-label">Phone</div><div class="detail-field-value" style="font-size:12px;">${c.phone || '—'}</div></div>
    </div>
    <div style="font-size:12px;color:var(--text-muted);margin-top:4px;">${sessions.filter(s=>s.clientId===id).length} sessions logged total</div>
  `;
  openModal('client-detail');
}

function archiveClient() {
  const c = clients.find(c => c.id === detailClientId);
  if (c) { c.active = !c.active; save('jbj_clients', clients); }
  closeModal();
  renderClients();
  toast(c.active ? c.fn + ' reactivated' : c.fn + ' archived');
}

// ── WORKOUTS ─────────────────────────────────────────────────
function renderWorkouts() {
  const sel = document.getElementById('workout-client-select');
  sel.innerHTML = clients.filter(c=>c.active).map(c => `<option value="${c.id}">${c.fn}</option>`).join('');
  const now = new Date();
  document.getElementById('workout-date-badge').textContent = now.toLocaleDateString('en-ZA',{day:'numeric',month:'short',year:'numeric'});
  if (exerciseRows.length === 0) {
    exerciseRows = [{name:'Back squat',sets:4,reps:6,weight:80},{name:'Romanian deadlift',sets:3,reps:8,weight:60}];
  }
  renderExerciseRows();
  loadClientWorkouts();
}

function renderExerciseRows() {
  document.getElementById('exercise-rows').innerHTML = exerciseRows.map((e,i) => `
    <div class="exercise-row-item">
      <select onchange="exerciseRows[${i}].name=this.value">
        ${EXERCISE_LIST.map(ex=>`<option ${ex===e.name?'selected':''}>${ex}</option>`).join('')}
      </select>
      <input type="number" value="${e.sets}" min="1" max="10" onchange="exerciseRows[${i}].sets=+this.value">
      <input type="number" value="${e.reps}" min="1" max="50" onchange="exerciseRows[${i}].reps=+this.value">
      <input type="number" value="${e.weight}" min="0" step="2.5" onchange="exerciseRows[${i}].weight=+this.value">
      <button class="remove-ex" onclick="removeExRow(${i})">×</button>
    </div>`).join('');
}

function addExerciseRow() {
  exerciseRows.push({name:'Deadlift',sets:3,reps:8,weight:60});
  renderExerciseRows();
}

function removeExRow(i) {
  exerciseRows.splice(i,1);
  renderExerciseRows();
}

function loadClientWorkouts() {
  const id = +document.getElementById('workout-client-select').value;
  const clientSessions = sessions.filter(s=>s.clientId===id).slice().reverse().slice(0,8);
  document.getElementById('session-history').innerHTML = clientSessions.length ? clientSessions.map(s=>`
    <div class="history-item">
      <div class="history-head">
        <span class="history-name">${s.type}</span>
        <span class="history-date">${s.date}</span>
      </div>
      ${s.notes ? `<div class="history-type">${s.notes}</div>` : ''}
      <div class="history-exercises">${s.exercises.map(e=>`<span class="ex-chip">${e.name} ${e.sets}×${e.reps}${e.weight?'@'+e.weight+'kg':''}</span>`).join('')}</div>
    </div>`).join('')
  : '<p style="color:var(--text-muted);font-size:13px;">No sessions yet.</p>';
}

function logSession() {
  const clientId = +document.getElementById('workout-client-select').value;
  const type     = document.getElementById('session-type').value;
  const notes    = document.getElementById('session-notes').value;
  const now = new Date();
  const date = now.toLocaleDateString('en-ZA',{day:'numeric',month:'short'});
  const newSession = { id: Date.now(), clientId, date, type, notes, exercises: JSON.parse(JSON.stringify(exerciseRows)) };
  sessions.unshift(newSession);
  save('jbj_sessions', sessions);
  exerciseRows = [];
  renderWorkouts();
  const c = clients.find(c=>c.id===clientId);
  toast('Session logged for ' + (c?c.fn:'client'));
}

// ── PROGRESS ─────────────────────────────────────────────────
function populateProgressSelect() {
  const sel = document.getElementById('progress-client-select');
  sel.innerHTML = clients.filter(c=>c.active).map(c=>`<option value="${c.id}">${c.fn}</option>`).join('');
}

function renderProgress() {
  const id = +document.getElementById('progress-client-select').value;
  const c  = clients.find(c=>c.id===id);
  if (!c) return;
  const cw = weights[id] || [c.sw];
  const current = cw[cw.length-1];
  const diff = (current - c.sw).toFixed(1);
  const sign = diff >= 0 ? '+' : '';
  const toGoal = Math.abs(current - c.tw).toFixed(1);
  const progressPct = c.sw===c.tw ? 100 : Math.min(100, Math.max(0, Math.round(Math.abs(c.sw-current)/Math.abs(c.sw-c.tw)*100)));
  const sessionCount = sessions.filter(s=>s.clientId===id).length;

  document.getElementById('progress-stats').innerHTML = `
    <div class="stat-card"><div class="stat-icon green"><svg viewBox="0 0 20 20"><path d="M10 3v14M6 7l4-4 4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></div><div class="stat-value">${c.sw} kg</div><div class="stat-label">Start weight</div></div>
    <div class="stat-card"><div class="stat-icon blue"><svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="6" fill="none" stroke="currentColor" stroke-width="1.5"/></svg></div><div class="stat-value">${current} kg</div><div class="stat-label">Current weight</div><div class="stat-trend ${diff<=0?'up':'neutral'}">${sign}${diff} kg</div></div>
    <div class="stat-card"><div class="stat-icon orange"><svg viewBox="0 0 20 20"><polyline points="3,14 7,9 11,11 15,5 17,7" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></div><div class="stat-value">${c.tw} kg</div><div class="stat-label">Target weight</div><div class="stat-trend neutral">${toGoal} kg to go</div></div>
    <div class="stat-card"><div class="stat-icon green"><svg viewBox="0 0 20 20"><rect x="3" y="4" width="14" height="13" rx="2" fill="none" stroke="currentColor" stroke-width="1.5"/></svg></div><div class="stat-value">${sessionCount}</div><div class="stat-label">Sessions logged</div></div>
  `;

  document.getElementById('weight-badge').textContent = progressPct + '% to goal';

  // Draw chart
  drawWeightChart(cw, c);

  // Goals
  document.getElementById('goals-section').innerHTML = `
    <div class="goal-item"><div class="goal-label"><span>Weight goal</span><span class="goal-pct">${progressPct}%</span></div><div class="progress-bar"><div class="progress-fill" style="width:${progressPct}%"></div></div></div>
    <div class="goal-item" style="margin-top:14px;"><div class="goal-label"><span>Session adherence</span><span class="goal-pct">87%</span></div><div class="progress-bar"><div class="progress-fill blue" style="width:87%"></div></div></div>
    <div class="goal-item" style="margin-top:14px;"><div class="goal-label"><span>Programme completion</span><span class="goal-pct">${Math.min(100,sessionCount*5)}%</span></div><div class="progress-bar"><div class="progress-fill" style="width:${Math.min(100,sessionCount*5)}%;background:var(--orange);"></div></div></div>
  `;

  // PRs
  const clientPrs = prs[id] || [];
  document.getElementById('prs-section').innerHTML = clientPrs.length ? clientPrs.map(p=>`
    <div class="pr-item"><span class="pr-lift">${p.lift}</span><span class="pr-val">${p.weight}</span></div>`).join('')
  : '<p style="color:var(--text-muted);font-size:13px;">No PRs logged yet.</p>';
}

function drawWeightChart(data, client) {
  const canvas = document.getElementById('weight-chart');
  const wrap = document.getElementById('weight-chart-wrap');
  canvas.width = wrap.clientWidth || 400;
  canvas.height = 160;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0,0,canvas.width,canvas.height);

  const pad = { top:20, right:16, bottom:28, left:40 };
  const W = canvas.width - pad.left - pad.right;
  const H = canvas.height - pad.top - pad.bottom;

  const min = Math.min(...data, client.tw) - 2;
  const max = Math.max(...data) + 2;
  const range = max - min || 1;

  const xStep = W / Math.max(data.length - 1, 1);

  // Grid lines
  ctx.strokeStyle = 'rgba(255,255,255,0.05)';
  ctx.lineWidth = 1;
  for (let i=0; i<=4; i++) {
    const y = pad.top + H * (i/4);
    ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(pad.left+W, y); ctx.stroke();
    const val = (max - (range * i/4)).toFixed(1);
    ctx.fillStyle = 'rgba(153,153,153,0.7)';
    ctx.font = '10px DM Mono, monospace';
    ctx.textAlign = 'right';
    ctx.fillText(val, pad.left - 6, y + 4);
  }

  // Target line
  const targetY = pad.top + H * (1 - (client.tw - min) / range);
  ctx.strokeStyle = 'rgba(251,146,60,0.35)';
  ctx.lineWidth = 1;
  ctx.setLineDash([4,4]);
  ctx.beginPath(); ctx.moveTo(pad.left, targetY); ctx.lineTo(pad.left+W, targetY); ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = 'rgba(251,146,60,0.7)';
  ctx.font = '10px DM Mono, monospace';
  ctx.textAlign = 'left';
  ctx.fillText('Goal', pad.left+W+2, targetY+4);

  // Area fill
  const grad = ctx.createLinearGradient(0, pad.top, 0, pad.top+H);
  grad.addColorStop(0, 'rgba(74,222,128,0.18)');
  grad.addColorStop(1, 'rgba(74,222,128,0)');
  ctx.beginPath();
  data.forEach((v,i) => {
    const x = pad.left + i * xStep;
    const y = pad.top + H * (1 - (v - min) / range);
    i===0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
  });
  ctx.lineTo(pad.left + (data.length-1)*xStep, pad.top+H);
  ctx.lineTo(pad.left, pad.top+H);
  ctx.closePath();
  ctx.fillStyle = grad;
  ctx.fill();

  // Line
  ctx.strokeStyle = '#4ade80';
  ctx.lineWidth = 2;
  ctx.lineJoin = 'round';
  ctx.beginPath();
  data.forEach((v,i) => {
    const x = pad.left + i * xStep;
    const y = pad.top + H * (1 - (v - min) / range);
    i===0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
  });
  ctx.stroke();

  // Dots
  data.forEach((v,i) => {
    const x = pad.left + i * xStep;
    const y = pad.top + H * (1 - (v - min) / range);
    ctx.beginPath();
    ctx.arc(x, y, 3.5, 0, Math.PI*2);
    ctx.fillStyle = '#4ade80';
    ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.arc(x, y, 1.5, 0, Math.PI*2);
    ctx.fill();
  });

  // X labels
  ctx.fillStyle = 'rgba(153,153,153,0.7)';
  ctx.font = '10px DM Mono, monospace';
  ctx.textAlign = 'center';
  const labelCount = Math.min(data.length, 7);
  for (let i=0; i<labelCount; i++) {
    const idx = Math.round(i * (data.length-1) / (labelCount-1));
    const x = pad.left + idx * xStep;
    ctx.fillText('Wk'+(idx+1), x, pad.top+H+16);
  }
}

function addWeighIn() {
  const inp = document.getElementById('new-weight');
  const val = parseFloat(inp.value);
  if (isNaN(val) || val < 20 || val > 300) { toast('Enter a valid weight'); return; }
  const id = +document.getElementById('progress-client-select').value;
  if (!weights[id]) weights[id] = [];
  weights[id].push(val);
  save('jbj_weights', weights);
  inp.value = '';
  renderProgress();
  const c = clients.find(c=>c.id===id);
  toast('Weigh-in logged: ' + val + ' kg');
}

// ── SCHEDULE ─────────────────────────────────────────────────
function renderSchedule() {
  const now = new Date();
  const monday = new Date(now);
  const day = now.getDay() || 7;
  monday.setDate(now.getDate() - day + 1);
  const sunday = new Date(monday); sunday.setDate(monday.getDate() + 6);
  document.getElementById('schedule-week').textContent =
    monday.toLocaleDateString('en-ZA',{day:'numeric',month:'short'}) + ' – ' +
    sunday.toLocaleDateString('en-ZA',{day:'numeric',month:'short',year:'numeric'});

  const usedTimes = [...new Set(schedule.map(s=>s.time))].sort();
  const table = document.getElementById('schedule-table');

  let html = '<div class="sch-header"></div>';
  DAYS.forEach(d => html += `<div class="sch-header">${d}</div>`);

  usedTimes.forEach(t => {
    html += `<div class="sch-time">${t}</div>`;
    DAYS.forEach(d => {
      const slot = schedule.find(s => s.day===d && s.time===t);
      let block = '';
      if (slot) {
        const colorClass = slot.type==='S&C Class' ? 'blue' : slot.type==='Assessment' ? 'orange' : 'green';
        const label = slot.type==='S&C Class' ? 'S&C Class' : (clients.find(c=>c.id===slot.clientId)?.fn || '?');
        block = `<div class="sch-block ${colorClass}">${label}<br><span style="font-weight:400;opacity:0.7;">${slot.type==='1-on-1'?'1-on-1':slot.type}</span></div>`;
      }
      html += `<div class="sch-cell">${block}</div>`;
    });
  });

  table.innerHTML = html;

  // populate booking modal client list
  document.getElementById('book-client').innerHTML = clients.filter(c=>c.active).map(c=>`<option value="${c.id}">${c.fn}</option>`).join('');
}

function bookSession() {
  const clientId = +document.getElementById('book-client').value;
  const day      = document.getElementById('book-day').value;
  const time     = document.getElementById('book-time').value;
  const type     = document.getElementById('book-type').value;
  schedule.push({ day, time, clientId: type==='S&C Class'?0:clientId, type });
  save('jbj_schedule', schedule);
  closeModal();
  renderSchedule();
  const c = clients.find(c=>c.id===clientId);
  toast('Session booked: ' + (type==='S&C Class'?'S&C Class':c?.fn) + ' ' + day + ' @ ' + time);
}

// ── ADD CLIENT ───────────────────────────────────────────────
function saveNewClient() {
  const fn = document.getElementById('new-fn').value.trim();
  if (!fn) { toast('Enter a first name'); return; }
  const colors = ['green','blue','orange'];
  const id = Date.now();
  const sw = parseFloat(document.getElementById('new-sw').value) || 80;
  const tw = parseFloat(document.getElementById('new-tw').value) || 70;
  const newClient = {
    id, fn,
    ln:    document.getElementById('new-ln').value.trim(),
    goal:  document.getElementById('new-goal').value,
    freq:  +document.getElementById('new-freq').value,
    sw, tw,
    email: document.getElementById('new-email').value.trim(),
    phone: document.getElementById('new-phone').value.trim(),
    active: true,
    avatar: (fn[0] + (document.getElementById('new-ln').value.trim()[0]||fn[1]||'X')).toUpperCase(),
    color: colors[clients.length % 3],
  };
  clients.push(newClient);
  weights[id] = [sw];
  save('jbj_clients', clients);
  save('jbj_weights', weights);
  ['new-fn','new-ln','new-sw','new-tw','new-email','new-phone'].forEach(id2 => { const el=document.getElementById(id2); if(el) el.value=''; });
  closeModal();
  renderClients();
  document.getElementById('stat-clients').textContent = clients.filter(c=>c.active).length;
  toast(fn + ' added to your roster');
}

// ── MODALS ───────────────────────────────────────────────────
function openModal(name) {
  document.getElementById('modal-bg').classList.add('open');
  document.getElementById('modal-' + name).classList.add('open');
}
function closeModal() {
  document.getElementById('modal-bg').classList.remove('open');
  document.querySelectorAll('.modal').forEach(m => m.classList.remove('open'));
}

// ── TOAST ────────────────────────────────────────────────────
let toastTimer;
function toast(msg) {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'toast';
    t.className = 'toast';
    t.innerHTML = '<span class="toast-dot"></span><span id="toast-msg"></span>';
    document.body.appendChild(t);
  }
  clearTimeout(toastTimer);
  document.getElementById('toast-msg').textContent = msg;
  t.classList.add('show');
  toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
}

// ── INIT ─────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  renderDashboard();

  // Close modal on bg click
  document.getElementById('modal-bg').addEventListener('click', closeModal);

  // Redraw chart on resize
  window.addEventListener('resize', () => {
    const progPage = document.getElementById('page-progress');
    if (progPage.classList.contains('active')) renderProgress();
  });
});
